export class ParentTask {
    public parentTaskID: number;
    public taskName: string;
    public projID: number;
    public userID: number;
    public status = 0;

    constructor() {

    }

}
