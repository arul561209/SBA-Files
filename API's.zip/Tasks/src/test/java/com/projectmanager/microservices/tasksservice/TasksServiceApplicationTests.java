package com.projectmanager.microservices.tasksservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TasksServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
