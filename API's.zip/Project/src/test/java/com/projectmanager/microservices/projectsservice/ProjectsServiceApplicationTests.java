package com.projectmanager.microservices.projectsservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
